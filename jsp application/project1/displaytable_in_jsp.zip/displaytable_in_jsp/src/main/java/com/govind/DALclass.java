package com.govind;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DALclass {
	Connection conn = null;
	Statement st = null;
	String qry, cs;
	ResultSet rst;
	public ArrayList<emp> fetchRecords()
	{
		ArrayList<emp> l1=new ArrayList<>();
		try {
			String url="jdbc:postgresql://localhost:5432/postgres";
			String user="postgres";
			String password="Postgres";
			Class.forName("org.postgresql.Driver");
			conn=DriverManager.getConnection(url,user,password);
			st = conn.createStatement();
			qry = "select * from emp";
			rst = st.executeQuery(qry);
			while(rst.next()) {
				int empno = rst.getInt("empid");
				String ename = rst.getString("ename");
				String job = rst.getString("jobrole");
				double salary=rst.getDouble("sal");
				emp e = new emp(empno, ename, job, salary);
				l1.add(e);
			}
			st.close();
			conn.close();
			rst.close();
		}catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return l1;	
	}
}
