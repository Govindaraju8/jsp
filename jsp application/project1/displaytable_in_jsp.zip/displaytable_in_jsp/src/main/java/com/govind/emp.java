package com.govind;

public class emp {
    private int empid;
    private String ename;
    private String jobrole;
    private double sal;

    public emp(int empid, String ename, String jobrole, double sal) {
        this.empid = empid;
        this.ename = ename;
        this.jobrole = jobrole;
        this.sal = sal;
    }

    // Getter and Setter methods for empid
    public int getEmpid() {
        return empid;
    }

    public void setEmpid(int empid) {
        this.empid = empid;
    }

    // Getter and Setter methods for ename
    public String getEname() {
        return ename;
    }

    public void setEname(String ename) {
        this.ename = ename;
    }

    // Getter and Setter methods for jobrole
    public String getJobrole() {
        return jobrole;
    }

    public void setJobrole(String jobrole) {
        this.jobrole = jobrole;
    }

    // Getter and Setter methods for sal
    public double getSal() {
        return sal;
    }

    public void setSal(double sal) {
        this.sal = sal;
    }
}
